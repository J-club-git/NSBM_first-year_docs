<!DOCTYPE html>
<html>
<head>
    <title>Mathematical Operations</title>
</head>
<body>
    <?php
        // Create variables and assign values
        $x = 6;
        $y = 4;

        // Calculate the sum, difference, product, and division
        $sum = $x + $y;
        $difference = $x - $y;
        $product = $x * $y;
        $division = $x / $y;
    ?>

    <h1>Mathematical Operations</h1>
    <p>Sum: <?php echo $sum; ?></p>
    <p>Difference: <?php echo $difference; ?></p>
    <p>Product: <?php echo $product; ?></p>
    <p>Division: <?php echo $division; ?></p>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <?php
       
        $x = 6;
        $y = 4;

     
        $sum = $x + $y;
        $difference = $x - $y;
        $product = $x * $y;
        $division = $x / $y;
    ?>

    <h1>Mathematical Operations</h1>
    <p>Sum: <?php echo $sum; ?></p>
    <p>Difference: <?php echo $difference; ?></p>
    <p>Product: <?php echo $product; ?></p>
    <p>Division: <?php echo $division; ?></p>

    <h1>Count from 5 to 15</h1>
    <?php
       
        for ($i = 5; $i <= 15; $i++) {
            echo $i . "<br>";
        }
    ?>

    
<form method="post">
        <label for="units">Enter Number of Units:</label>
        <input type="text" name="units" id="units">
        <input type="submit" value="Calculate">
    </form>

    <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $units = intval($_POST["units"]);

            // Calculate electricity bill based on the given conditions
            if ($units <= 50) {
                $bill = $units * 3.50;
            } elseif ($units <= 100) {
                $bill = 50 * 3.50 + ($units - 50) * 4.00;
            } elseif ($units <= 150) {
                $bill = 50 * 3.50 + 50 * 4.00 + ($units - 100) * 5.20;
            } else {
                $bill = 50 * 3.50 + 50 * 4.00 + 50 * 5.20 + ($units - 150) * 6.50;
            }

            echo "<p>Electricity Bill: Rs. " . $bill . "</p>";
        }
    ?>

<form method="post">
        <label for="dayNumber">Enter Number (1 to 7):</label>
        <input type="text" name="dayNumber" id="dayNumber">
        <input type="submit" value="Show Day">
    </form>

    <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $dayNumber = intval($_POST["dayNumber"]);

            // Use switch/case to show the day of the week
            switch ($dayNumber) {
                case 1:
                    $dayOfWeek = "Monday";
                    break;
                case 2:
                    $dayOfWeek = "Tuesday";
                    break;
                case 3:
                    $dayOfWeek = "Wednesday";
                    break;
                case 4:
                    $dayOfWeek = "Thursday";
                    break;
                case 5:
                    $dayOfWeek = "Friday";
                    break;
                case 6:
                    $dayOfWeek = "Saturday";
                    break;
                case 7:
                    $dayOfWeek = "Sunday";
                    break;
                default:
                    $dayOfWeek = "Invalid number";
                    break;
            }

            echo "<p>Day of the Week: " . $dayOfWeek . "</p>";
        }
    ?>

<?php
        // Create an array called 'fruits'
        $fruits = array("Apple", "Banana", "Orange", "Grapes", "Mango");

        // Use a foreach loop to print each element of the array
        foreach ($fruits as $fruit) {
            echo $fruit . "<br>";
        }
    ?>
</body>
</html>
